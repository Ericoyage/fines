const {
    Client,
    GatewayIntentBits,
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    ChannelType,
    StringSelectMenuBuilder,
    PermissionsBitField,
    AttachmentBuilder,
} = require('discord.js');
const path = require('path');
const config = require('./config.js');
const fetch = require('node-fetch');
const { createCanvas, loadImage } = require('canvas');
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
    ],
});
let gameState = {
    players: [],
    allPlayers: [],
    playerRoles: new Map(),
    mafias: [],
    doctor: null,
    detector: null,
    bodyguard: null,
    mayor: null,
    president: null,
    presidentUsedAbility: false,
    gameActive: false,
    protectedPlayer: null,
    shieldedPlayer: null,
    shieldedPlayerRound: null,
    killedPlayer: null,
    votes: new Map(),
    skipVotes: 0,
    totalVotes: 0,
    mafiaActions: new Map(),
    doctorActionTaken: false,
    doctorPhaseEnded: false,
    detectorUsedAbility: false,
    bodyguardUsedAbility: false,
    bodyguardPhaseEnded: false,
    gameMessage: null,
    mafiaMessages: new Map(),
    mafiaInteractions: new Map(),
    doctorInteraction: null,
    detectorInteraction: null,
    bodyguardInteraction: null,
    mayorInteraction: null,
    votePhaseActive: false,
    mafiaPhaseEnded: false,
    mafiaTimeout: null,
    currentRound: 0,
    princess: null,
    princessAbilityUsed: false,
    mafiaThread: null,
    townCrier: null,  
    // Harlot properties
    lovers: [],
    loversSaveChance: true,
    jester: null,
    harlot: null,
    harlotTarget: null,  // Tracks the player visited by the Harlot each night
};
const ownerPath = path.join(__dirname, 'owner.json');
let owner = require(ownerPath);

// Save changes to the config file
function saveConfig() {
    fs.writeFileSync(ownerPath, JSON.stringify(owner, null, 4), 'utf8');
}

const interactions = new Map();
let gameInterval = null;
let gameTimeouts = [];

client.on('ready', () => {
    console.log(`Logged in as ${client.user.tag}`);
    console.log('Coded by Eric');

    // Set the bot's status to "Watching Eric Bots"
    client.user.setActivity('Coded by Eric', { type: 'WATCHING' });

    resetGame();
});

client.on('messageCreate', async (message) => {
    try {
        if (message.author.bot) return;
        if (message.content === '-الذيب') {
            const member = message.member;
            
            // Check if the user has an allowed role or is an owner
            if (
                !owner.allowedChannels.includes(message.channel.id) &&
                !owner.ownerIds.includes(message.author.id) &&
                !member.roles.cache.some((role) => owner.allowedRoleIds.includes(role.id))
            ) {
                //return message.channel.send('❌ **ليس لديك إذن لتشغيل اللعبة.**');
            }

            if (gameState.gameActive) {
                return message.channel.send('⚠️ **اللعبة جارية بالفعل.**');
            }

            await startGame(message);
        }
    } catch (error) {
        console.error('Error in messageCreate:', error);
        await message.channel.send('❌ **حدث خطأ غير متوقع أثناء معالجة الرسالة.**');
    }
});

client.on('messageCreate', async (message) => {
    if (message.author.bot) return;

    if (message.content === '-ايقاف') {
        const member = message.member;

        // Check if the user has an allowed role or is an owner
        if (
            !owner.allowedChannels.includes(message.channel.id) &&
            !owner.ownerIds.includes(message.author.id) &&
            !member.roles.cache.some((role) => owner.allowedRoleIds.includes(role.id))
        ) {
            //return message.channel.send('❌ **ليس لديك إذن لإيقاف اللعبة.**');
        }

        if (!gameState.gameActive) {
            return message.channel.send('**مافي لعبة ياكوتش**');
        }

        resetGame();
        return message.channel.send('**تم ايقاف اللعبة**');
    }
});

async function startGame(message) {
    try {
        resetGame();
        gameState.gameActive = true;
        gameState.allPlayers = [];
        
        let timeLeft = config.startTime / 1000;

        // Load the background image
        const background = await loadImage(path.join(__dirname, 's2.png'));
        const canvas = createCanvas(background.width, background.height);
        const ctx = canvas.getContext('2d');

        // Draw the static background image
        ctx.drawImage(background, 0, 0, canvas.width, canvas.height);

        // Send the initial message with the timer and player count
        const attachment = new AttachmentBuilder(canvas.toBuffer(), { name: 'game-start.png' });
        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('join_game')
                .setLabel('دخول')
                .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
                .setCustomId('leave_game')
                .setLabel('انسحاب')
                .setStyle(ButtonStyle.Secondary)
        );

        gameState.gameMessage = await message.channel.send({
            content: `**@here ستبدأ اللعبه خلال : ${timeLeft} seconds\nعدد اللاعبين: 0/${config.maxPlayers}**`,
            files: [attachment],
            components: [row],
        });

        // Update game message text only every second
        gameInterval = setInterval(async () => {
            try {
                timeLeft--;

                // Update only the message content with the new time and player count
                if (gameState.gameMessage) {
                    await gameState.gameMessage.edit({
                        content: `**@here : ${timeLeft} seconds\nعدد اللاعبين: ${gameState.players.length}/${config.maxPlayers}**`,
                        components: [row],
                    });
                }

                if (timeLeft <= 0) {
                    clearInterval(gameInterval);
                    gameInterval = null;

                    const disabledRow = new ActionRowBuilder().addComponents(
                        new ButtonBuilder()
                            .setCustomId('join_game')
                            .setLabel('دخول')
                            .setStyle(ButtonStyle.Secondary)
                            .setDisabled(true),
                        new ButtonBuilder()
                            .setCustomId('leave_game')
                            .setLabel('انسحاب')
                            .setStyle(ButtonStyle.Secondary)
                            .setDisabled(true)
                    );

                    if (gameState.gameMessage) {
                        await gameState.gameMessage.edit({
                            content: `@here بدأت اللعبة!\nعدد اللاعبين: ${gameState.players.length}/${config.maxPlayers}`,
                            components: [disabledRow],
                        }).catch((error) => {
                            console.error('Error editing game message:', error);
                            gameState.gameMessage = null;
                        });
                    }

                    if (gameState.players.length >= config.minPlayers) {
                        await assignRoles(message.channel);
                    } else {
                        gameState.gameActive = false;
                        await message.channel.send('**تم ايقاف اللعبة تحتاج الى 6 اشخاص للبدء**');
                        resetGame();
                    }
                }
            } catch (error) {
                console.error('Error in game interval:', error);
            }
        }, 1000);
    } catch (error) {
        console.error('Error in startGame:', error);
        await message.channel.send('❌ **Error starting the game.**');
    }
}
client.on('interactionCreate', async (interaction) => {
    try {
        if (!interaction.isButton()) return;

        const { customId } = interaction;

        if (customId === 'join_game') {
            if (gameState.players.length >= config.maxPlayers) {
                await interaction.reply({
                    content: '❌ **تم الوصول إلى الحد الأقصى من اللاعبين.**',
                    ephemeral: true,
                });
                return;
            }

            if (!gameState.players.includes(interaction.user.id)) {
                gameState.players.push(interaction.user.id);
                if (!gameState.allPlayers.includes(interaction.user.id)) {
                    gameState.allPlayers.push(interaction.user.id);
                }
                interactions.set(interaction.user.id, interaction);
                await interaction.reply({
                    content: '✅ **لقد انضممت إلى اللعبة!**',
                    ephemeral: true,
                });
            } else {
                await interaction.reply({
                    content: '❌ **أنت بالفعل في اللعبة!**',
                    ephemeral: true,
                });
            }
        } else if (customId === 'leave_game') {
            if (gameState.players.includes(interaction.user.id)) {
                gameState.players = gameState.players.filter((id) => id !== interaction.user.id);
                await interaction.reply({
                    content: '❌ **لقد غادرت اللعبة.**',
                    ephemeral: true,
                });
            } else {
                await interaction.reply({
                    content: '❌ **أنت لست في اللعبة.**',
                    ephemeral: true,
                });
            }
        } else if (customId.startsWith('kill_')) {
            await handleMafiaKill(interaction);
        } else if (customId.startsWith('protect_')) {
            await handleDoctorProtect(interaction);
        } else if (customId.startsWith('detect_')) {
            await handleDetectorDetect(interaction);
        } else if (customId === 'skip_detect') {
            await handleDetectorSkip(interaction);
        } else if (customId.startsWith('shield_')) {
            await handleBodyguardShield(interaction);
        } else if (customId === 'skip_shield') {
            await handleBodyguardSkip(interaction);
        } else if (customId.startsWith('visit_')) {  // New case for the Harlot
            await handleHarlotVisit(interaction);
        } else if (customId.startsWith('vote_')) {
            await handleVote(interaction);
        } else if (customId === 'skip_vote') {
            await handleSkipVote(interaction);
        } else if (customId === 'president_ability') {
            await handlePresidentAbility(interaction);
        } else if (customId.startsWith('president_select_')) {
            await handlePresidentSelection(interaction);
        }
    } catch (error) {
        console.error('Error in interactionCreate:', error);
        if (!interaction.replied) {
            await interaction.reply({
                content: '❌ **حدث خطأ غير متوقع. حاول مرة أخرى.**',
                ephemeral: true,
            });
        }
    }
});

async function assignRoles(channel) {
    try {
        if (!gameState.gameActive) return;

        gameState.allPlayers = [...gameState.players];

        const shuffledPlayers = gameState.players.sort(() => Math.random() - 0.5);

        if (shuffledPlayers.length < 6) {
            await channel.send('❌ **عدد اللاعبين غير كافٍ لتعيين جميع الأدوار. تحتاج على الأقل إلى 6 لاعبين.**');
            resetGame();
            return;
        }

        let mafiaCount = 1;
        if (shuffledPlayers.length >= 8) mafiaCount = 2;
        if (shuffledPlayers.length >= 15) mafiaCount = 3;
        if (shuffledPlayers.length >= 23) mafiaCount = 4;

        gameState.mafias = shuffledPlayers.slice(0, mafiaCount);
        gameState.doctor = shuffledPlayers[mafiaCount];
        gameState.detector = shuffledPlayers[mafiaCount + 1];
        gameState.bodyguard = shuffledPlayers[mafiaCount + 2];
        gameState.mayor = shuffledPlayers[mafiaCount + 3];
        gameState.president = shuffledPlayers[mafiaCount + 4];
        gameState.princess = shuffledPlayers[mafiaCount + 5];
        gameState.harlot = shuffledPlayers[mafiaCount + 6];
        gameState.townCrier = shuffledPlayers[mafiaCount + 7];
        gameState.jester = shuffledPlayers[mafiaCount + 8];
        const lovers = shuffledPlayers.slice(mafiaCount + 11, mafiaCount + 12); // Adjust indices based on roles
        gameState.lovers = lovers;

        shuffledPlayers.slice(mafiaCount + 11).forEach((player) => {
            gameState.playerRoles.set(player, '👤 قروي');
        });

        for (const mafia of gameState.mafias) {
            gameState.playerRoles.set(mafia, 'ذئب');
        }

        gameState.playerRoles.set(gameState.doctor, 'طبيب 🧑‍⚕️');
        gameState.playerRoles.set(gameState.detector, 'المحقق 🕵️‍♂️');
        gameState.playerRoles.set(gameState.bodyguard, 'الحارس 🛡️');
        gameState.playerRoles.set(gameState.mayor, 'العمدة 👨‍✈️');
        gameState.playerRoles.set(gameState.president, 'الملك 👑');
        gameState.playerRoles.set(gameState.harlot, 'المغرية 💋');
        gameState.playerRoles.set(gameState.townCrier, 'ام زكي 🧕🏻');
        gameState.playerRoles.set(gameState.jester, 'المهرج 🎭');
        gameState.playerRoles.set(gameState.princess, 'الاميرة 👸🏼');
        gameState.lovers.forEach((lover) => {
            gameState.playerRoles.set(lover, 'العاشق 💖');
        });

        // Notify Lovers about each other
        const [lover1, lover2] = gameState.lovers || [];
        if (lover1 && lover2) {
            const lover1Interaction = interactions.get(lover1);
            const lover2Interaction = interactions.get(lover2);

            if (lover1Interaction) {
                await lover1Interaction.followUp({
                    ephemeral: true,
                    content: `💖 **أنت عاشق! شريكك هو <@${lover2}> ودوره هو: ${gameState.playerRoles.get(lover2).toUpperCase()}.**`,
                });
            }

            if (lover2Interaction) {
                await lover2Interaction.followUp({
                    ephemeral: true,
                    content: `💖 **أنت عاشق! شريكك هو <@${lover1}> ودوره هو: ${gameState.playerRoles.get(lover1).toUpperCase()}.**`,
                });
            }
        }

        for (const playerId of gameState.players) {
            const role = gameState.playerRoles.get(playerId);
            const interaction = interactions.get(playerId);

            if (interaction) {
                if (!interaction.replied) {
                    await interaction.deferReply({ ephemeral: true }).catch((error) => {
                        console.error(`Error deferring interaction for player ${playerId}:`, error);
                    });
                }
                await interaction.followUp({
                    ephemeral: true,
                    content: `**دورك هو:** **${role.toUpperCase()}**.`,
                }).catch((error) => {
                    console.error(`Error sending role to player ${playerId}:`, error);
                });
            } else {
                console.error(`Interaction for player ${playerId} not found.`);
            }
        }

        if (gameState.mafias.length >= 50) {
            try {
                const mafiaThread = await channel.threads.create({
                    name: `wolf Chat - Game ${gameState.currentRound}`,
                    autoArchiveDuration: 60,
                    type: ChannelType.PrivateThread,
                    invitable: false,
                });

                for (const mafiaId of gameState.mafias) {
                    await mafiaThread.members.add(mafiaId).catch((error) => {
                        console.error(`Error adding mafia member ${mafiaId} to thread:`, error);
                    });
                }

                gameState.mafiaThread = mafiaThread;

                const mafiaMentions = gameState.mafias.map(id => `<@${id}>`).join(', ');

                await mafiaThread.send(`${mafiaMentions}\n💀 **هذا هو الشات الخاص الذئاب. يمكنك مناقشة خططك هنا.**`);
            } catch (error) {
                console.error('Error creating mafia thread:', error);
                await channel.send('❌ **حدث خطأ أثناء إنشاء الشات الخاص الذئاب.**');
            }
        }

        await channel.send('🚨 **تم الكشف عن الأدوار لجميع اللاعبين. ستبدأ اللعبة في 5 ثواني.**');

        const timeout = setTimeout(() => startMafiaPhase(channel), 5000);
        gameTimeouts.push(timeout);
    } catch (error) {
        console.error('Error in assignRoles:', error);
        await channel.send('❌ **حدث خطأ أثناء تعيين الأدوار.**');
    }
}


function resetGame() {
    if (gameState.gameMessage) {
        disableButtons(gameState.gameMessage);
    }

    if (gameState.mafiaThread) {
        try {
            gameState.mafiaThread.delete().catch((error) => {
                console.error('Error deleting mafia thread:', error);
            });
            gameState.mafiaThread = null;
        } catch (error) {
            console.error('Error deleting mafia thread:', error);
        }
    }

    gameState = {
        players: [],
        allPlayers: [],
        playerRoles: new Map(),
        mafias: [],
        doctor: null,
        detector: null,
        bodyguard: null,
        mayor: null,
        gameActive: false,
        protectedPlayer: null,
        shieldedPlayer: null,
        shieldedPlayerRound: null,
        killedPlayer: null,
        votes: new Map(),
        skipVotes: 0,
        totalVotes: 0,
        mafiaActions: new Map(),
        doctorActionTaken: false,
        doctorPhaseEnded: false,
        detectorUsedAbility: false,
        bodyguardUsedAbility: false,
        bodyguardPhaseEnded: false,
        gameMessage: null,
        mafiaMessages: new Map(),
        mafiaInteractions: new Map(),
        doctorInteraction: null,
        detectorInteraction: null,
        bodyguardInteraction: null,
        mayorInteraction: null,
        votePhaseActive: false,
        mafiaPhaseEnded: false,
        mafiaTimeout: null,
        currentRound: 0,
        mafiaThread: null,
    };

    interactions.clear();

    if (gameInterval) {
        clearInterval(gameInterval);
        gameInterval = null;
    }

    gameTimeouts.forEach((timeout) => clearTimeout(timeout));
    gameTimeouts = [];

    console.log('Game state has been reset.');
}


async function disableButtons(message) {
    if (!message) return;
    try {
        const fetchedMessage = await message.fetch().catch((error) => {
            if (error.code === 10008) {
                console.error('Message was deleted before it could be fetched.');
                return null;
            } else {
                throw error;
            }
        });

        if (!fetchedMessage) return;

        const disabledComponents = fetchedMessage.components.map((row) => {
            return new ActionRowBuilder().addComponents(
                row.components.map((button) =>
                    ButtonBuilder.from(button).setDisabled(true)
                )
            );
        });

        await fetchedMessage.edit({ components: disabledComponents }).catch((error) => {
            console.error('Error editing message to disable buttons:', error);
        });
    } catch (error) {
        if (error.code === 10008) {
            console.error('Error: Tried to disable buttons on a message that no longer exists.');
        } else {
            console.error('Error while disabling buttons:', error);
        }
    }
}

async function startMafiaPhase(channel) {
    try {
        if (!gameState.gameActive) return;

        gameState.currentRound += 1;

        if (gameState.shieldedPlayerRound !== null && gameState.currentRound > gameState.shieldedPlayerRound) {
            gameState.shieldedPlayer = null;
            gameState.shieldedPlayerRound = null;
        }

        gameState.mafiaActions.clear();
        gameState.mafiaPhaseEnded = false;

        const alivePlayers = gameState.players.filter((player) => !gameState.mafias.includes(player));

        if (alivePlayers.length === 0) {
            await channel.send('🎉 **فاز الذئاب! تم القضاء على جميع القرووين.**');
            gameState.gameActive = false;
            checkWinConditions(channel);
            return;
        }

        let availableTargets = alivePlayers;
        if (gameState.shieldedPlayer && gameState.players.includes(gameState.shieldedPlayer)) {
            availableTargets = availableTargets.filter((player) => player !== gameState.shieldedPlayer);
        }

        if (availableTargets.length === 0) {
            await channel.send('❌ **لا يوجد لاعبين يمكن للذئاب قتلهم.**');
            await new Promise(resolve => setTimeout(resolve, 3000)); // 3-second delay
            resolveMafiaActions(channel);
            return;
        }

        await channel.send('🐺 🔪 **الذئاب، حان دوركم لاختيار ضحيتكم.**');
        await new Promise(resolve => setTimeout(resolve, 2000)); // 2-second delay before buttons are displayed

        const buttons = availableTargets.map((player) =>
            new ButtonBuilder()
                .setCustomId(`kill_${player}`)
                .setLabel(
                    `${channel.guild.members.cache.get(player)?.displayName || 'Unknown'}`
                )
                .setStyle(ButtonStyle.Danger)
        );

        const rows = createButtonRows(buttons);

        for (const mafiaId of gameState.mafias) {
            const mafiaInteraction = interactions.get(mafiaId);

            if (mafiaInteraction) {
                if (mafiaInteraction.replied || mafiaInteraction.deferred) {
                    const message = await mafiaInteraction.followUp({
                        content: '🐺 **لقد تم اختيارك كـ ذئب. يجب عليك اختيار لاعب لقتله. إذا اخترت لاعبين مختلفين، سيتم اختيار الضحية عشوائيًا.**',
                        components: rows,
                        ephemeral: true,
                    });
                    gameState.mafiaMessages.set(mafiaId, message.id);
                    gameState.mafiaInteractions.set(mafiaId, mafiaInteraction);
                } else {
                    await mafiaInteraction.deferReply({ ephemeral: true });
                    const message = await mafiaInteraction.editReply({
                        content: '🐺  **لقد تم اختيارك كـ ذئب. يجب عليك اختيار لاعب لقتله. إذا اخترت لاعبين مختلفين، سيتم اختيار الضحية عشوائيًا.**',
                        components: rows,
                    });
                    gameState.mafiaMessages.set(mafiaId, message.id);
                    gameState.mafiaInteractions.set(mafiaId, mafiaInteraction);
                }
            } else {
                console.error(`Mafia interaction for player ${mafiaId} not found.`);
            }
        }

        gameState.mafiaTimeout = setTimeout(async () => {
            await handleMafiaTimeout(channel);
        }, config.mafiaKillTime);

        gameTimeouts.push(gameState.mafiaTimeout);
    } catch (error) {
        console.error('Error in startMafiaPhase:', error);
        await channel.send('❌ **حدث خطأ أثناء مرحلة الذئاب.**');
    }
}

async function handleMafiaTimeout(channel) {
    try {
        if (!gameState.gameActive || gameState.mafiaPhaseEnded) return;

        for (const mafiaId of gameState.mafias.slice()) {
            if (!gameState.mafiaActions.has(mafiaId)) {
                await channel.send(`💤 **الذئب <@${mafiaId}> رقد وتم طرده من اللعبة.**`);
                await new Promise(resolve => setTimeout(resolve, 2000)); // 2-second delay before removal
                gameState.players = gameState.players.filter((player) => player !== mafiaId);
                gameState.mafias = gameState.mafias.filter((mafia) => mafia !== mafiaId);

                const mafiaInteraction = gameState.mafiaInteractions.get(mafiaId);
                if (mafiaInteraction) {
                    try {
                        await mafiaInteraction.editReply({
                            content: '❌ **لم تقم باختيار أحد لقتله وتم إقصاؤك من اللعبة.**',
                            components: [],
                        });
                    } catch (err) {
                        console.error('Error editing Mafia message:', err);
                    }
                }
            }
        }

        if (gameState.mafias.length === 0) {
            await channel.send('🎉 **القرووين فازوا! تم القضاء على جميع الذئاب.**');
            gameState.gameActive = false;
            checkWinConditions(channel);
            return;
        }

        await resolveMafiaActions(channel);
    } catch (error) {
        console.error('Error in handleMafiaTimeout:', error);
    }
}

async function handleMafiaKill(interaction) {
    try {
        if (!gameState.gameActive || gameState.mafiaPhaseEnded) return;

        const mafiaId = interaction.user.id;

        if (!gameState.mafias.includes(mafiaId)) {
            await interaction.reply({
                content: '❌ **أنت لست ذئب.**',
                ephemeral: true,
            });
            return;
        }

        if (!gameState.mafiaActions.has(mafiaId)) {
            const playerId = interaction.customId.split('_')[1];

            if (!gameState.players.includes(playerId) || gameState.mafias.includes(playerId)) {
                await interaction.reply({
                    content: '❌ **لا يمكنك قتل هذا اللاعب.**',
                    ephemeral: true,
                });
                return;
            }

            gameState.mafiaActions.set(mafiaId, playerId);

            await interaction.update({
                content: `🔪 **لقد اخترت قتل <@${playerId}>. انتظر حتى يختار الذئاب الآخرون.**`,
                components: [],
            });

            if (gameState.mafiaActions.size === gameState.mafias.length) {
                if (gameState.mafiaTimeout) {
                    clearTimeout(gameState.mafiaTimeout);
                    gameState.mafiaTimeout = null;
                }
                await new Promise(resolve => setTimeout(resolve, 3000)); // 3-second delay before resolving
                await resolveMafiaActions(interaction.channel);
            }
        } else {
            await interaction.reply({
                content: '❌ **لقد قمت بالفعل باتخاذ قرارك.**',
                ephemeral: true,
            });
        }
    } catch (error) {
        console.error('Error in handleMfiaKill:', error);
        if (!interaction.replied && !interaction.deferred) {
            await interaction.reply({
                content: '❌ **حدث خطأ أثناء محاولة القتل. حاول مرة أخرى.**',
                ephemeral: true,
            });
        }
    }
}


async function resolveMafiaActions(channel) {
    try {
        if (!gameState.gameActive || gameState.mafiaPhaseEnded) return;
        gameState.mafiaPhaseEnded = true;

        const selectedTargets = Array.from(gameState.mafiaActions.values());

        if (selectedTargets.length === 0) {
            //await channel.send('🗡️ **الذئاب لم تختار أي ضحية. الانتقال إلى المرحلة التالية.**');
            await new Promise(resolve => setTimeout(resolve, 3000)); // 3-second delay
           // await channel.send('💀 **الذئاب لم تقم بقتل أي شخص هذه الليلة.**');

            // Start Harlot Phase before Doctor Phase
            const timeout = setTimeout(() => startHarlotPhase(channel), 5000);
            gameTimeouts.push(timeout);
            return;
        }

        let targetToKill;
        if (selectedTargets.every((val, i, arr) => val === arr[0])) {
            targetToKill = selectedTargets[0];
        } else {
            targetToKill = selectedTargets[Math.floor(Math.random() * selectedTargets.length)];
           // await channel.send('🗡️ **الذئاب اختاروا أهدافًا مختلفة. سيتم اختيار الضحية عشوائيًا.**');
            await new Promise(resolve => setTimeout(resolve, 3000)); // 3-second delay
        }

        gameState.killedPlayer = targetToKill;

        for (const mafiaId of gameState.mafias) {
            const mafiaInteraction = gameState.mafiaInteractions.get(mafiaId);
            if (mafiaInteraction) {
                try {
                    await mafiaInteraction.followUp({
                        content: `🗡️ **الضحية النهائية هي <@${targetToKill}>.**`,
                        ephemeral: true,
                    });
                } catch (err) {
                    console.error('Error notifying Mafia:', err);
                }
            }
        }

        await channel.send('🔪 **الذئاب انتهت من اختيارها.**');

        // Start Harlot Phase
        await new Promise(resolve => setTimeout(resolve, 3000)); // 3-second delay
        await channel.send(' **الآن دور المغرية لاختيار لاعب للزيارة 💋.**');

        const timeout = setTimeout(() => startHarlotPhase(channel), 5000);
        gameTimeouts.push(timeout);
    } catch (error) {
        console.error('Error in resolveMafiaActions:', error);
    }
}
async function startHarlotPhase(channel) {
    try {
        if (!gameState.gameActive || !gameState.harlot || !gameState.players.includes(gameState.harlot)) {
           // await channel.send('💋 **المغرية غير موجود أو لم تعد على قيد الحياة. الانتقال إلى المرحلة التالية.**');
            startDoctorPhase(channel);
            return;
        }

        const alivePlayers = gameState.players.filter(player => player !== gameState.harlot);

        const buttons = alivePlayers.map(player =>
            new ButtonBuilder()
                .setCustomId(`visit_${player}`)
                .setLabel(`${channel.guild.members.cache.get(player)?.displayName || 'Unknown'}`)
                .setStyle(ButtonStyle.Primary)
        );

        const rows = createButtonRows(buttons);

        const harlotInteraction = interactions.get(gameState.harlot);

        if (harlotInteraction) {
            if (harlotInteraction.replied || harlotInteraction.deferred) {
                const message = await harlotInteraction.followUp({
                    content: '💋 **لقد تم اختيارك كـ مغرية. اختر لاعبًا لزيارته الليلة.**',
                    components: rows,
                    ephemeral: true,
                });
                gameState.harlotInteraction = message.id;
            } else {
                await harlotInteraction.deferReply({ ephemeral: true });
                const message = await harlotInteraction.editReply({
                    content: '💋 **لقد تم اختيارك كـ مغرية. اختر لاعبًا لزيارته الليلة.**',
                    components: rows,
                });
                gameState.harlotInteraction = message.id;
            }
        } else {
            console.error('Harlot interaction not found.');
        }

        // Timeout for the Harlot Phase
        const timeout = setTimeout(() => {
            if (!gameState.harlotTarget && gameState.gameActive) {
                //channel.send('💋 **المغرية لم تقم بزيارة أي شخص. الانتقال إلى المرحلة التالية.**');
                startDoctorPhase(channel);
            }
        }, config.harlotPhaseTime || 15000); // Adjust time as needed

        gameTimeouts.push(timeout);
    } catch (error) {
        console.error('Error in startHarlotPhase:', error);
       // await channel.send('❌ **حدث خطأ أثناء مرحلة المغرية.**');
        startDoctorPhase(channel);
    }
}
async function handleHarlotVisit(interaction) {
    try {
        if (!gameState.gameActive || gameState.harlot === null) {
            await interaction.reply({
                content: '❌ **اللعبة غير نشطة أو المغرية غير موجود.**',
                ephemeral: true,
            });
            return;
        }

        const channel = interaction.channel; 
        const harlotId = interaction.user.id;

        if (harlotId !== gameState.harlot) {
            await interaction.reply({
                content: '❌ **أنت لست المغرية.**',
                ephemeral: true,
            });
            return;
        }

        const targetId = interaction.customId.split('_')[1];

        if (!gameState.players.includes(targetId)) {
            await interaction.reply({
                content: '❌ **لا يمكنك زيارة هذا اللاعب.**',
                ephemeral: true,
            });
            return;
        }

        // Set the Harlot's target
        gameState.harlotTarget = targetId;

        await interaction.update({
            content: `✅ **لقد اخترت زيارة <@${targetId}> هذه الليلة.**`,
            components: [],
        });

        // Announce the Harlot's visit
        await interaction.channel.send(` **المغرية قررت زيارة <@${targetId}> الليلة.💋**`);

        // Now use setTimeout after the channel has been defined
        setTimeout(() => startDoctorPhase(channel), 3000);

    } catch (error) {
        console.error('Error in handleHarlotVisit:', error);
        if (!interaction.replied && !interaction.deferred) {
            await interaction.reply({
                content: '❌ **حدث خطأ أثناء تحديد الهدف. حاول مرة أخرى.**',
                ephemeral: true,
            });
        }
    }
}



async function handleDoctorProtect(interaction) {
    try {
        if (!gameState.gameActive || gameState.doctorPhaseEnded) return;

        if (!gameState.doctorActionTaken) {
            const playerId = interaction.customId.split('_')[1];

            if (!gameState.players.includes(playerId)) {
                await interaction.reply({
                    content: '❌ **لا يمكنك حماية هذا اللاعب.**',
                    ephemeral: true,
                });
                return;
            }

            gameState.protectedPlayer = playerId;
            gameState.doctorActionTaken = true;

            if (gameState.doctorTimeout) {
                clearTimeout(gameState.doctorTimeout);
                gameState.doctorTimeout = null;
            }

            await interaction.update({
                content: `✅ **لقد اخترت حماية <@${playerId}>.**`,
                components: [],
            });

            await interaction.channel.send('💉 **الطبيب قام بحماية أحد اللاعبين.**');

            // Delay before transitioning to the next phase
            await new Promise(resolve => setTimeout(resolve, 3000)); // 3-second delay
            gameState.doctorPhaseEnded = true;
            startBodyguardPhase(interaction.channel);
        } else {
            if (!interaction.deferred) await interaction.deferReply({ ephemeral: true });
            await interaction.followUp({
                content: '❌ **لقد قمت بالفعل باتخاذ قرارك.**',
                ephemeral: true,
            });
        }
    } catch (error) {
        console.error('Error in handleDoctorProtect:', error);
        if (!interaction.replied && !interaction.deferred) {
            await interaction.reply({
                content: '❌ **حدث خطأ أثناء الحماية. حاول مرة أخرى.**',
                ephemeral: true,
            });
        }
    }
}

async function startDoctorPhase(channel) {
    try {
        if (!gameState.gameActive) return;

        gameState.doctorActionTaken = false;
        gameState.doctorPhaseEnded = false;

        const alivePlayers = gameState.players;

        if (!alivePlayers.includes(gameState.doctor)) {
            //await channel.send('💉 **الطبيب غير موجود. الانتقال إلى المرحلة التالية.**');
            await new Promise(resolve => setTimeout(resolve, 3000)); // 3-second delay
            startBodyguardPhase(channel);
            return;
        }

        await channel.send('**الطبيب، حان دورك لحماية أحد اللاعبين.💉**');

        const buttons = alivePlayers.map((player) =>
            new ButtonBuilder()
                .setCustomId(`protect_${player}`)
                .setLabel(`${channel.guild.members.cache.get(player)?.displayName || 'Unknown'}`)
                .setStyle(ButtonStyle.Primary)
        );

        const rows = createButtonRows(buttons);
        const doctorInteraction = interactions.get(gameState.doctor);

        if (doctorInteraction) {
            if (doctorInteraction.replied || doctorInteraction.deferred) {
                const message = await doctorInteraction.followUp({
                    content: '💉 **لقد تم اختيارك كـ طبيب. يمكنك حماية أي لاعب، بما في ذلك نفسك، من القتل.**',
                    components: rows,
                    ephemeral: true,
                });
                gameState.doctorInteraction = doctorInteraction;
            } else {
                await doctorInteraction.deferReply({ ephemeral: true });
                await doctorInteraction.editReply({
                    content: '💉 **لقد تم اختيارك كـ طبيب. يمكنك حماية أي لاعب، بما في ذلك نفسك، من القتل.**',
                    components: rows,
                });
                gameState.doctorInteraction = doctorInteraction;
            }
        } else {
            console.error('Doctor interaction not found.');
        }

        gameState.doctorTimeout = setTimeout(async () => {
            if (!gameState.doctorActionTaken && gameState.gameActive && !gameState.doctorPhaseEnded) {
                await channel.send(`💉 **الطبيب رقد. سيتم طرد الطبيب <@${gameState.doctor}> من اللعبة.**`);
                await new Promise(resolve => setTimeout(resolve, 3000)); // 3-second delay
                if (gameState.doctorInteraction) {
                    try {
                        await gameState.doctorInteraction.editReply({
                            content: '❌ **لم تقم باختيار أي شخص للحماية.**',
                            components: [],
                        });
                    } catch (err) {
                        console.error('Error editing Doctor message:', err);
                    }
                }
                gameState.players = gameState.players.filter(
                    (player) => player !== gameState.doctor
                );
                gameState.doctor = null;
                gameState.doctorPhaseEnded = true;
                startBodyguardPhase(channel);
            }
        }, config.docActionTime);

        gameTimeouts.push(gameState.doctorTimeout);
    } catch (error) {
        console.error('Error in startDoctorPhase:', error);
        await channel.send('❌ **حدث خطأ أثناء مرحلة الطبيب.**');
    }
}


async function startBodyguardPhase(channel) {
    try {
        if (!gameState.gameActive) return;

        if (gameState.bodyguardUsedAbility || !gameState.players.includes(gameState.bodyguard)) {
            if (gameState.bodyguardUsedAbility) {
             //   await channel.send('🛡️ **الحارس استخدم قدرته بالفعل لذا سيتم التخطي.**');
            } else {
               // await channel.send('🛡️ **الحارس غير موجود لذا سيتم التخطي.**');
            }
            await new Promise(resolve => setTimeout(resolve, 3000)); // 3-second delay before moving to the next phase
            startDetectorPhase(channel);
            return;
        }

        gameState.bodyguardPhaseEnded = false;

        // Delay before notifying the Knight of their turn
        await new Promise(resolve => setTimeout(resolve, 2000)); // 2-second delay
        await channel.send('🛡️ **الحارس حان دورك لإعطاء الدرع.**');

       // await channel.send('🛡️ **يمكنك إعطاء درع لأحد اللاعبين مرة واحدة في اللعبة.**');

        const alivePlayers = gameState.players;

        const buttons = alivePlayers.map(player =>
            new ButtonBuilder()
                .setCustomId(`shield_${player}`)
                .setLabel(`${channel.guild.members.cache.get(player)?.displayName || 'Unknown'}`)
                .setStyle(ButtonStyle.Primary)
        );

        const skipButton = new ButtonBuilder()
            .setCustomId('skip_shield')
            .setLabel('تخطي إعطاء الدرع')
            .setStyle(ButtonStyle.Secondary);

        const rows = createButtonRows([...buttons, skipButton]);

        const bodyguardInteraction = interactions.get(gameState.bodyguard);

        if (bodyguardInteraction) {
            if (bodyguardInteraction.replied || bodyguardInteraction.deferred) {
                const message = await bodyguardInteraction.followUp({
                    content: '🛡️ **لقد تم اختيارك كـ الحارس. يمكنك إعطاء درع لأحد اللاعبين مرة واحدة في اللعبة.**',
                    components: rows,
                    ephemeral: true,
                });
                gameState.bodyguardInteraction = {
                    id: message.id,
                    interaction: bodyguardInteraction,
                };
            } else {
                await bodyguardInteraction.deferReply({ ephemeral: true });
                const message = await bodyguardInteraction.editReply({
                    content: '🛡️ **لقد تم اختيارك كـ الحارس. يمكنك إعطاء درع لأحد اللاعبين مرة واحدة في اللعبة.**',
                    components: rows,
                });
                gameState.bodyguardInteraction = {
                    id: message.id,
                    interaction: bodyguardInteraction,
                };
            }
        } else {
            console.error('Bodyguard interaction not found.');
        }

        const timeout = setTimeout(async () => {
            if (gameState.gameActive && !gameState.bodyguardPhaseEnded) {
                if (!gameState.bodyguardUsedAbility) {
                    await bodyguardInteraction.followUp({
                        content: '❌ **انتهى الوقت ولم تقم باتخاذ قرار. يمكنك إعطاء الدرع في جولة قادمة.**',
                        ephemeral: true,
                    });
                }
                gameState.bodyguardPhaseEnded = true;
                await new Promise(resolve => setTimeout(resolve, 3000)); // 3-second delay before moving to the next phase
                startDetectorPhase(channel);
            }
        }, config.bodyguardPhaseTime);

        gameTimeouts.push(timeout);
    } catch (error) {
        console.error('Error in startBodyguardPhase:', error);
        await channel.send('❌ **حدث خطأ أثناء مرحلة الحارس.**');
    }
}

async function harlotAction(harlotPlayer, targetPlayer, channel) {
    if (gameState.playerRoles.get(targetPlayer) === 'mafia') {
        await channel.send(`💔 ** زارت <@${targetPlayer}>، وكلاهما مات بسبب أنه كان مافيا!**`);
        // Remove both the Harlot and the Mafia target from the game
        gameState.players = gameState.players.filter(player => player !== harlotPlayer && player !== targetPlayer);
        gameState.mafias = gameState.mafias.filter(mafia => mafia !== targetPlayer);
    } else {
        await channel.send(`💋 ** زارت <@${targetPlayer}> في الليل، وحماها من الهجوم.**`);
        gameState.harlotTarget = targetPlayer;  // Set the target for protection
    }
}

async function handleBodyguardShield(interaction) {
    try {
        if (!gameState.gameActive || gameState.bodyguardPhaseEnded) return;

        if (gameState.bodyguardUsedAbility) {
            await interaction.reply({
                content: '❌ **لقد استخدمت بالفعل قدرتك على إعطاء الدرع.**',
                ephemeral: true,
            });
            return;
        }

        const playerId = interaction.customId.split('_')[1];

        if (!gameState.players.includes(playerId)) {
            await interaction.reply({
                content: '❌ **لا يمكنك إعطاء الدرع لهذا اللاعب.**',
                ephemeral: true,
            });
            return;
        }

        gameState.bodyguardUsedAbility = true;
        gameState.shieldedPlayer = playerId;
        gameState.shieldedPlayerRound = gameState.currentRound + 1;

        await interaction.update({
            content: `✅ **لقد اخترت إعطاء درع لـ <@${playerId}>. سيتم حمايته في الجولة القادمة.**`,
            components: [],
        });

        await interaction.channel.send(`🛡️ **الحارس قام بإعطاء الدرع لـ <@${playerId}>.**`);

        gameState.bodyguardPhaseEnded = true;

        // Delay before moving to the next phase
        await new Promise(resolve => setTimeout(resolve, 3000)); // 3-second delay
        startDetectorPhase(interaction.channel);
    } catch (error) {
        console.error('Error in handleBodyguardShield:', error);
        if (!interaction.replied && !interaction.deferred) {
            await interaction.reply({
                content: '❌ **حدث خطأ أثناء محاولة إعطاء الدرع. حاول مرة أخرى.**',
                ephemeral: true,
            });
        }
    }
}

async function handleBodyguardSkip(interaction) {
    try {
        if (!gameState.gameActive || gameState.bodyguardPhaseEnded) return;

        if (gameState.bodyguardUsedAbility) {
            await interaction.reply({
                content: '❌ **لقد استخدمت بالفعل قدرتك على إعطاء الدرع.**',
                ephemeral: true,
            });
            return;
        }

        await interaction.update({
            content: '⏩ **لقد اخترت تخطي إعطاء الدرع في هذه الجولة. يمكنك استخدامه في جولة قادمة.**',
            components: [],
        });

        await interaction.channel.send(`🛡️ **الحارس قرر عدم إعطاء الدرع في هذه الجولة.**`);

        gameState.bodyguardPhaseEnded = true;

        // Delay before moving to the next phase
        await new Promise(resolve => setTimeout(resolve, 3000)); // 3-second delay
        startDetectorPhase(interaction.channel);
    } catch (error) {
        console.error('Error in handleBodyguardSkip:', error);
        if (!interaction.replied && !interaction.deferred) {
            await interaction.reply({
                content: '❌ **حدث خطأ أثناء محاولة التخطي. حاول مرة أخرى.**',
                ephemeral: true,
            });
        }
    }
}


async function startDetectorPhase(channel) {
    try {
        if (!gameState.gameActive) return;

        if (gameState.detectorUsedAbility || !gameState.players.includes(gameState.detector)) {
            if (gameState.detectorUsedAbility) {
                //await channel.send('🕵️ **المحقق استخدم قدرته بالفعل لذا سيتم التخطي.**');
            } else {
              //  await channel.send('🕵️ **المحقق غير موجود لذا سيتم التخطي.**');
            }
            await new Promise(resolve => setTimeout(resolve, 3000)); // 3-second delay before moving to next phase
            resolveNightPhase(channel);
            return;
        }

        // Delay before notifying the المحقق
        await new Promise(resolve => setTimeout(resolve, 2000)); // 2-second delay
        await channel.send('🕵️ **المحقق، حان دورك لكشف دور أحد اللاعبين.**');

        const alivePlayers = gameState.players.filter(player => player !== gameState.detector);

        const buttons = alivePlayers.map(player =>
            new ButtonBuilder()
                .setCustomId(`detect_${player}`)
                .setLabel(`${channel.guild.members.cache.get(player)?.displayName || 'Unknown'}`)
                .setStyle(ButtonStyle.Primary)
        );

        const skipButton = new ButtonBuilder()
            .setCustomId('skip_detect')
            .setLabel('تخطي الكشف')
            .setStyle(ButtonStyle.Secondary);

        const rows = createButtonRows([...buttons, skipButton]);

        const detectorInteraction = interactions.get(gameState.detector);

        if (detectorInteraction) {
            if (detectorInteraction.replied || detectorInteraction.deferred) {
                const message = await detectorInteraction.followUp({
                    content: '🕵️ **لقد تم اختيارك كـ محقق. يمكنك كشف دور أحد اللاعبين مرة واحدة في اللعبة.**',
                    components: rows,
                    ephemeral: true,
                });
                gameState.detectorInteraction = {
                    id: message.id,
                    interaction: detectorInteraction,
                };
            } else {
                await detectorInteraction.deferReply({ ephemeral: true });
                const message = await detectorInteraction.editReply({
                    content: '🕵️ **لقد تم اختيارك كـ محقق. يمكنك كشف دور أحد اللاعبين مرة واحدة في اللعبة.**',
                    components: rows,
                });
                gameState.detectorInteraction = {
                    id: message.id,
                    interaction: detectorInteraction,
                };
            }
        } else {
            console.error('Detector interaction not found.');
        }

        // Delay before skipping to the next phase if the المحقق does not act
        const timeout = setTimeout(async () => {
            if (gameState.gameActive) {
                if (!gameState.detectorUsedAbility) {
                    await detectorInteraction.followUp({
                        content: '❌ **انتهى الوقت ولم تقم باتخاذ قرار. يمكنك الكشف في جولة قادمة.**',
                        ephemeral: true,
                    });
                    await new Promise(resolve => setTimeout(resolve, 3000)); // 3-second delay before next phase
                }
                resolveNightPhase(channel);
            }
        }, config.detectorPhaseTime);

        gameTimeouts.push(timeout);
    } catch (error) {
        console.error('Error in startDetectorPhase:', error);
        await channel.send('❌ **حدث خطأ أثناء مرحلة المحقق.**');
    }
}


async function handleDetectorDetect(interaction) {
    try {
        if (!gameState.gameActive) return;

        if (gameState.detectorUsedAbility) {
            await interaction.reply({
                content: '❌ **لقد استخدمت بالفعل قدرتك على الكشف.**',
                ephemeral: true,
            });
            return;
        }

        const playerId = interaction.customId.split('_')[1];

        if (!gameState.players.includes(playerId)) {
            await interaction.reply({
                content: '❌ **لا يمكنك كشف دور هذا اللاعب.**',
                ephemeral: true,
            });
            return;
        }

        gameState.detectorUsedAbility = true;

        const role = gameState.playerRoles.get(playerId) || 'مواطن';

        await interaction.update({
            content: `🔍 **لقد اخترت كشف دور <@${playerId}>. دوره هو: ${role.toUpperCase()}.**`,
            components: [],
        });

        await interaction.channel.send(`🔍 **المحقق قام بكشف دور <@${playerId}>.**`);

        const timeout = setTimeout(() => resolveNightPhase(interaction.channel), 5000);
        gameTimeouts.push(timeout);
    } catch (error) {
        console.error('Error in handleDetectorDetect:', error);
        if (!interaction.replied && !interaction.deferred) {
            await interaction.reply({
                content: '❌ **حدث خطأ أثناء محاولة الكشف. حاول مرة أخرى.**',
                ephemeral: true,
            });
        }
    }
}

async function handleDetectorSkip(interaction) {
    try {
        if (!gameState.gameActive) return;

        if (gameState.detectorUsedAbility) {
            await interaction.reply({
                content: '❌ **لقد استخدمت بالفعل قدرتك على الكشف.**',
                ephemeral: true,
            });
            return;
        }

        await interaction.update({
            content: '⏩ **لقد اخترت تخطي الكشف في هذه الجولة. يمكنك الكشف في جولة قادمة.**',
            components: [],
        });

        await interaction.channel.send(`🔍 **المحقق قرر عدم الكشف في هذه الجولة.**`);

        const timeout = setTimeout(() => resolveNightPhase(interaction.channel), 5000);
        gameTimeouts.push(timeout);
    } catch (error) {
        console.error('Error in handleDetectorSkip:', error);
        if (!interaction.replied && !interaction.deferred) {
            await interaction.reply({
                content: '❌ **حدث خطأ أثناء محاولة التخطي. حاول مرة أخرى.**',
                ephemeral: true,
            });
        }
    }
}
async function resolveNightPhase(channel) {
    try {
        if (!gameState.gameActive) return;

        const killedPlayer = gameState.killedPlayer;
        const protectedPlayer = gameState.protectedPlayer;
        const harlotPlayer = gameState.harlot;
        const harlotTarget = gameState.harlotTarget;
        const [lover1, lover2] = gameState.lovers || [];
        if (lover1 && lover2) {
            if (killedPlayer === lover1 && gameState.loversSaveChance) {
                gameState.loversSaveChance = false;
                gameState.killedPlayer = null;
                await channel.send(`💖 **تم إنقاذ <@${lover1}> بواسطة الحب <@${lover2}>.**`);
                return;
            } else if (killedPlayer === lover2 && gameState.loversSaveChance) {
                gameState.loversSaveChance = false;
                gameState.killedPlayer = null;
                await channel.send(`💖 **تم إنقاذ <@${lover2}> بواسطة الحب <@${lover1}>.**`);
                return;
            }
        }
        // Handle Harlot visiting a player
        if (harlotPlayer && harlotTarget) {
            const harlotTargetRole = gameState.playerRoles.get(harlotTarget);
        
            if (harlotTargetRole === 'ذئب') {
                // If the Harlot visited a Mafia, both die 💔 **زارت <@${harlotTarget}> وكان ذئبًا، لذا مات الاثنان!💔
                await channel.send(` **المغرية زارت <@${harlotTarget}> وكان ذئبًا، لذا مات الاثنان! 💔**`);
                gameState.players = gameState.players.filter(
                    (player) => player !== harlotPlayer && player !== harlotTarget
                );
                gameState.mafias = gameState.mafias.filter((mafia) => mafia !== harlotTarget);
        
                // Clear Harlot from the game state
                gameState.harlot = null;
                gameState.harlotTarget = null;
            } else if (harlotTarget === killedPlayer) {
                // If the Harlot protects a target from being killed 👨‍❤️‍💋‍👨 **<@${killedPlayer}> تم حمايته من الهجوم بواسطة زيارة المغرية!**
                await channel.send(`👨‍❤️‍💋‍👨 **<@${killedPlayer}> تم حمايته من الهجوم بواسطة زيارة المغرية!**`);
                gameState.killedPlayer = null; // Cancel the kill
            }
        }
        
        // Ensure killedPlayer is not processed further if protected
        if (gameState.killedPlayer === null) {
            await new Promise(resolve => setTimeout(resolve, 3000)); // Optional delay
            return; // Exit the function early since no one was killed
        }
        

        // Handle the killed player (if not protected by Doctor or Harlot)
        if (killedPlayer && killedPlayer !== protectedPlayer) {
            gameState.players = gameState.players.filter((player) => player !== killedPlayer);
            const role = gameState.playerRoles.get(killedPlayer);
        
            if (role === 'ام زكي 🧕🏻') {
                // Town Crier logic: Expose a random Mafia if killed by them
                if (gameState.mafias.length > 0) {
                    const randomMafia = gameState.mafias[Math.floor(Math.random() * gameState.mafias.length)];
                    await channel.send(
                        `🔊 **تم قتل ام زكي 🧕🏻 <@${killedPlayer}>! كشفت ام زكي عن الذئب <@${randomMafia}> اقبل موته!**`
                    );
                } else {
                    //await channel.send(`🔊 **تم قتل المنادي <@${killedPlayer}>! ولكن لم يكن هناك ذئاب للكشف عنها.**`);
                }
            }
        
            if (role === 'ذئب') {
                gameState.mafias = gameState.mafias.filter((mafia) => mafia !== killedPlayer);
            }
            if (killedPlayer === gameState.doctor) {
                gameState.doctor = null;
            }
            if (killedPlayer === gameState.detector) {
                gameState.detector = null;
            }
            if (killedPlayer === gameState.bodyguard) {
                gameState.bodyguard = null;
            }
            if (killedPlayer === gameState.mayor) {
                gameState.mayor = null;
            }
            if (killedPlayer === gameState.president) {
                gameState.president = null;
            }
        
            await channel.send(`💀 **تم قتل <@${killedPlayer}> هذه الليلة. دوره كان: ${role.toUpperCase()}**`);
            await new Promise(resolve => setTimeout(resolve, 3000)); // 3-second delay
        } else if (killedPlayer && killedPlayer === protectedPlayer) {
            await channel.send(
                `💉 **فشلت عملية القتل لأن <@${protectedPlayer}> تم حمايته من قبل الطبيب.**`
            );
            await new Promise(resolve => setTimeout(resolve, 3000)); // 3-second delay
        }
        
        // Reset night-specific states
        gameState.killedPlayer = null;
        gameState.protectedPlayer = null;
        gameState.harlotTarget = null;
        
        if (checkWinConditions(channel)) {
            return;
        }
        
        if (gameState.gameActive) {
            setTimeout(() => startVotePhase(channel), 3000); // 3-second delay before vote phase
        }
        
    } catch (error) {
        console.error('Error in resolveNightPhase:', error);
        await channel.send('❌ **حدث خطأ أثناء إنهاء المرحلة الليلية.**');
    }
}


async function checkWinConditions(channel) {
    try {
        let winnerMessage = null;
        let winningPlayers = [];
        let imageName = '';
        const points = JSON.parse(fs.readFileSync('./points.json', 'utf-8'));

        const mafiaCount = gameState.players.filter(player => gameState.playerRoles.get(player) === 'ذئب').length;
        const citizenCount = gameState.players.length - mafiaCount;

        // Determine the winning team
        if (mafiaCount === 0) {
            winnerMessage = '🎉 **القرووين !**';
            winningPlayers = gameState.players.filter(player => gameState.playerRoles.get(player) !== 'ذئب');
            imageName = 'v.png'; // Villagers win
        } else if (mafiaCount >= citizenCount) {
            winnerMessage = '💀 ** الذئاب!**';
            winningPlayers = gameState.players.filter(player => gameState.playerRoles.get(player) === 'ذئب');
            imageName = 'm.png'; // Mafia win
        }

        // Add the "المهرج" to winners
        const jester = gameState.players.find(player => gameState.playerRoles.get(player) === 'المهرج');
        if (jester) {
            winningPlayers.push(jester);
            await channel.send(`🎭 **المهرج <@${jester}> فاز مع الجميع!**`);
        }

        // Update points
        gameState.players.forEach(player => {
            const role = gameState.playerRoles.get(player);
            if (!points[player]) points[player] = 0; // Initialize points if not present

            if (winningPlayers.includes(player)) {
                if (role === 'ذئب') {
                    points[player] += 3; // Mafia gets 3 points
                } else {
                    points[player] += 1; // Other winners get 1 point
                }
            }
        });

        // Save updated points to the JSON file
        fs.writeFileSync('./points.json', JSON.stringify(points, null, 4));

        if (winnerMessage && winningPlayers.length > 0) {
            // Create mentions for the winning players
            const winnerMentions = winningPlayers.map(playerId => `<@${playerId}>`).join(', ');

            // Send the image and winner message
            const attachment = new AttachmentBuilder(path.join(__dirname, imageName));
            await channel.send({ files: [attachment], content: winnerMessage });

            // Send mentions in a separate message
            await channel.send(`${winnerMentions}`);

            resetGame();
            return true;
        }

        return false;
    } catch (error) {
        console.error('Error in checkWinConditions:', error);
        return false;
    }
}



function getAlivePlayers() {
    if (gameState.players.length === 0) return 'لا يوجد أحياء.';
    return gameState.players.map((id) => `<@${id}>`).join(', ');
}

async function startVotePhase(channel) {
    try {
        if (!gameState.gameActive || gameState.votePhaseActive) return;
        gameState.votePhaseActive = true;

        if (gameState.voteTimeout) {
            clearTimeout(gameState.voteTimeout);
            gameState.voteTimeout = null;
        }

        const alivePlayers = gameState.players;

        if (alivePlayers.length <= 2) {
            if (checkWinConditions(channel)) {
                return;
            }
        }

        // Create the voting buttons for players
        const buttons = alivePlayers.map((player) =>
            new ButtonBuilder()
                .setCustomId(`vote_${player}`)
                .setLabel(`${channel.guild.members.cache.get(player)?.displayName || 'Unknown'}`)
                .setStyle(ButtonStyle.Secondary)
        );

        // Create the skip vote button
        const skipButton = new ButtonBuilder()
            .setCustomId('skip_vote')
            .setLabel('تخطي التصويت')
            .setStyle(ButtonStyle.Secondary);

        // Create the President's button
        const presidentButton = new ButtonBuilder()
            .setCustomId('president_ability')
            .setLabel('استخدام قدر الملك')
            .setStyle(ButtonStyle.Primary);

        // Disable the President's button if they've used their ability or if President is not in game
        if (gameState.presidentUsedAbility || !gameState.players.includes(gameState.president)) {
            presidentButton.setDisabled(true);
        }

        const votingButtonRows = [];
        for (let i = 0; i < buttons.length; i += 5) {
            votingButtonRows.push(new ActionRowBuilder().addComponents(buttons.slice(i, i + 5)));
        }

        const controlButtonsRow = new ActionRowBuilder().addComponents(skipButton, presidentButton);

        await disableButtonsInChannel(channel);

        await channel.send({
            content: '🗳️ **حان الوقت للتصويت! اختر من تظن أنه الذئب أو اختر تخطي التصويت.**',
            components: [...votingButtonRows, controlButtonsRow],
        });

        gameState.voteTimeout = setTimeout(() => tallyVotes(channel), config.citizenVoteTime);
    } catch (error) {
        console.error('Error in startVotePhase:', error);
        await channel.send('❌ **حدث خطأ أثناء مرحلة التصويت.**');
    }
}

async function handleVote(interaction) {
    try {
        const playerId = interaction.customId.split('_')[1];

        if (!gameState.players.includes(interaction.user.id)) {
            await interaction.reply({
                content: '❌ **لا يمكنك التصويت لأنك لست في اللعبة أو تم إقصاؤك.**',
                ephemeral: true,
            });
            return;
        }

        if (!gameState.players.includes(playerId)) {
            await interaction.reply({
                content: '❌ **لا يمكنك التصويت لهذا اللاعب.**',
                ephemeral: true,
            });
            return;
        }

        if (!gameState.votes.has(interaction.user.id)) {
            let voteWeight = 1;

            if (interaction.user.id === gameState.mayor) {
                voteWeight = 2;
                await interaction.reply({
                    content: `✅ **تم تسجيل تصويتك بقوة صوتين للKnight <@${interaction.user.id}>.**`,
                    ephemeral: true,
                });
            } else {
                await interaction.reply({
                    content: '✅ **تم تسجيل تصويتك.**',
                    ephemeral: true,
                });
            }

            if (!gameState.voteCounts) {
                gameState.voteCounts = new Map();
            }

            gameState.votes.set(interaction.user.id, { target: playerId, weight: voteWeight });
            gameState.totalVotes += 1;

            let voteDisplayCounts = new Map();
            for (const vote of gameState.votes.values()) {
                if (vote.target !== 'skip') {
                    voteDisplayCounts.set(vote.target, (voteDisplayCounts.get(vote.target) || 0) + vote.weight);
                }
            }

            const updatedComponents = interaction.message.components.map((row) =>
                new ActionRowBuilder().addComponents(
                    row.components.map((button) => {
                        const targetPlayerId = button.customId.split('_')[1];
                        if (button.customId === 'skip_vote') return button;
                        if (button.customId === 'president_ability') return button;

                        const voteCount = voteDisplayCounts.get(targetPlayerId) || 0;

                        return ButtonBuilder.from(button).setLabel(
                            `${interaction.guild.members.cache.get(targetPlayerId)?.displayName || 'Unknown'} (${voteCount})`
                        );
                    })
                )
            );

            await interaction.message.edit({
                content: interaction.message.content,
                components: updatedComponents,
            });

            await checkIfAllVotedOrTimeout(interaction.channel);
        } else {
            await interaction.reply({ content: '❌ **لقد صوتت بالفعل.**', ephemeral: true });
        }
    } catch (error) {
        console.error('Error in handleVote:', error);
        if (!interaction.replied) {
            await interaction.reply({
                content: '❌ **حدث خطأ أثناء التصويت. حاول مرة أخرى.**',
                ephemeral: true,
            });
        }
    }
}

async function handleSkipVote(interaction) {
    try {
        if (!gameState.players.includes(interaction.user.id)) {
            await interaction.reply({
                content: '❌ **لا يمكنك التصويت لأنك لست في اللعبة أو تم إقصاؤك.**',
                ephemeral: true,
            });
            return;
        }

        if (!gameState.votes.has(interaction.user.id)) {
            let voteWeight = 1;

            if (interaction.user.id === gameState.mayor) {
                voteWeight = 2;
                await interaction.reply({
                    content: `✅ **تم تسجيل تصويتك بتخطي الدور بقوة صوتين الععمدة <@${interaction.user.id}>.**`,
                    ephemeral: true,
                });
            } else {
                await interaction.reply({
                    content: '✅ **تم تسجيل تصويتك بتخطي الدور.**',
                    ephemeral: true,
                });
            }

            gameState.votes.set(interaction.user.id, { target: 'skip', weight: voteWeight });
            gameState.skipVotes += voteWeight;
            gameState.totalVotes += 1;

            const updatedComponents = interaction.message.components.map((row) =>
                new ActionRowBuilder().addComponents(
                    row.components.map((button) => {
                        if (button.customId === 'skip_vote') {
                            return ButtonBuilder.from(button).setLabel(
                                `تخطي التصويت (${gameState.skipVotes})`
                            );
                        }
                        return button;
                    })
                )
            );

            await interaction.message.edit({
                content: interaction.message.content,
                components: updatedComponents,
            });

            await checkIfAllVotedOrTimeout(interaction.channel);
        } else {
            await interaction.reply({ content: '❌ **لقد صوتت بالفعل.**', ephemeral: true });
        }
    } catch (error) {
        console.error('Error in handleSkipVote:', error);
        if (!interaction.replied) {
            await interaction.reply({
                content: '❌ **حدث خطأ أثناء محاولة التخطي. حاول مرة أخرى.**',
                ephemeral: true,
            });
        }
    }
}

async function handlePresidentAbility(interaction) {
    try {
        if (!gameState.gameActive || !gameState.votePhaseActive) {
            await interaction.reply({
                content: '❌ **لا يمكنك استخدام هذه القدرة الآن.**',
                ephemeral: true,
            });
            return;
        }

        if (interaction.user.id !== gameState.president) {
            await interaction.reply({
                content: '❌ **هذه القدرة خاصة بالملك فقط.**',
                ephemeral: true,
            });
            return;
        }

        if (gameState.presidentUsedAbility) {
            await interaction.reply({
                content: '❌ **لقد استخدمت قدرتك بالفعل.**',
                ephemeral: true,
            });
            return;
        }

        // Mark that the President has used their ability
        gameState.presidentUsedAbility = true;

        // Create buttons for the President to select a player
        const alivePlayers = gameState.players.filter(player => player !== gameState.president);

        const buttons = alivePlayers.map((player) =>
            new ButtonBuilder()
                .setCustomId(`president_select_${player}`)
                .setLabel(`${interaction.guild.members.cache.get(player)?.displayName || 'Unknown'}`)
                .setStyle(ButtonStyle.Danger)
        );

        const rows = createButtonRows(buttons);

        await interaction.reply({
            content: '👑 **اختر اللاعب الذي تريد تحويل جميع الأصوات إليه.**',
            components: rows,
            ephemeral: true,
        });

    } catch (error) {
        console.error('Error in handlePresidentAbility:', error);
        if (!interaction.replied && !interaction.deferred) {
            await interaction.reply({
                content: '❌ **حدث خطأ أثناء استخدام القدرة. حاول مرة أخرى.**',
                ephemeral: true,
            });
        }
    }
}

async function handlePresidentSelection(interaction) {
    try {
        if (!gameState.gameActive || !gameState.votePhaseActive) {
            await interaction.reply({
                content: '❌ **لا يمكنك استخدام هذه القدرة الآن.**',
                ephemeral: true,
            });
            return;
        }

        if (interaction.user.id !== gameState.president) {
            await interaction.reply({
                content: '❌ **هذه القدرة خاصة بالملك فقط.**',
                ephemeral: true,
            });
            return;
        }

        const selectedPlayerId = interaction.customId.split('_')[2];

        if (!gameState.players.includes(selectedPlayerId)) {
            await interaction.reply({
                content: '❌ **لا يمكنك اختيار هذا اللاعب.**',
                ephemeral: true,
            });
            return;
        }

        gameState.votes.clear();
        gameState.totalVotes = 0;
        gameState.skipVotes = 0;

        for (const voterId of gameState.players) {
            let voteWeight = 1;

            if (voterId === gameState.mayor) {
                voteWeight = 2;
            }

            gameState.votes.set(voterId, { target: selectedPlayerId, weight: voteWeight });
        }

        gameState.totalVotes = gameState.players.length;

        await interaction.update({
            content: `👑 **لقد اخترت تحويل جميع الأصوات إلى <@${selectedPlayerId}>.**`,
            components: [],
        });

        await interaction.channel.send(`👑 **الملك استخدم قدرته وحول جميع الأصوات إلى <@${selectedPlayerId}>!**`);

        if (gameState.voteTimeout) {
            clearTimeout(gameState.voteTimeout);
            gameState.voteTimeout = null;
        }

        gameState.votePhaseActive = false;
        await tallyVotes(interaction.channel);

    } catch (error) {
        console.error('Error in handlePresidentSelection:', error);
        if (!interaction.replied && !interaction.deferred) {
            await interaction.reply({
                content: '❌ **حدث خطأ أثناء اختيار اللاعب. حاول مرة أخرى.**',
                ephemeral: true,
            });
        }
    }
}

async function checkIfAllVotedOrTimeout(channel) {
    try {
        const remainingPlayers = gameState.players.length;
        if (gameState.totalVotes >= remainingPlayers && gameState.votePhaseActive) {
            gameState.votePhaseActive = false;
            if (gameState.voteTimeout) {
                clearTimeout(gameState.voteTimeout);
                gameState.voteTimeout = null;
            }
            await tallyVotes(channel);
        }
    } catch (error) {
        console.error('Error in checkIfAllVotedOrTimeout:', error);
    }
}

async function tallyVotes(channel) {
    try {
        if (!gameState.gameActive) return;

        await disableButtonsInChannel(channel);

        if (gameState.votes.size === 0) {
            await channel.send('⚠️ **لم يتم التصويت من قبل أي شخص. سوف يتم تخطي الجولة.**');
            proceedToNextPhase(channel);
            return;
        }

        const voteCounts = {};
        for (const vote of gameState.votes.values()) {
            voteCounts[vote.target] = (voteCounts[vote.target] || 0) + vote.weight;
        }

        const maxVotes = Math.max(...Object.values(voteCounts));
        const playersWithMaxVotes = Object.keys(voteCounts).filter(
            (player) => voteCounts[player] === maxVotes
        );

        if (playersWithMaxVotes.includes('skip') && playersWithMaxVotes.length === 1) {
            await channel.send('🎲 **تم التصويت لتخطي الدور. لن يتم إقصاء أي لاعب.**');
        } else if (playersWithMaxVotes.length === 1) {
            const expelledPlayer = playersWithMaxVotes[0];

            // Check if the player is the princess and hasn't used their ability
            if (expelledPlayer === gameState.princess && !gameState.princessAbilityUsed) {
                gameState.princessAbilityUsed = true;
                await channel.send(`👑 **<@${expelledPlayer}> تم الكشف عن دورها كأميرة! لقد حمت نفسها ولن يتم إقصاؤها.**`);
                return proceedToNextPhase(channel);
            }

            // Normal expulsion logic
            gameState.players = gameState.players.filter((player) => player !== expelledPlayer);

            const role = gameState.playerRoles.get(expelledPlayer);
            if (role === 'ذئب') {
                gameState.mafias = gameState.mafias.filter((mafia) => mafia !== expelledPlayer);
            }
            if (expelledPlayer === gameState.doctor) {
                gameState.doctor = null;
            }
            if (expelledPlayer === gameState.detector) {
                gameState.detector = null;
            }
            if (expelledPlayer === gameState.bodyguard) {
                gameState.bodyguard = null;
            }
            if (expelledPlayer === gameState.mayor) {
                gameState.mayor = null;
            }
            if (expelledPlayer === gameState.president) {
                gameState.president = null;
            }

            await channel.send(` **تم إقصاء <@${expelledPlayer}> من اللعبة. دوره كان: ${role.toUpperCase()}**`);
        } else {
            await channel.send('⚖️ **حدث تعادل في الأصوات. لن يتم إقصاء أي لاعب.**');
        }

        gameState.votes.clear();
        gameState.skipVotes = 0;
        gameState.totalVotes = 0;
        gameState.votePhaseActive = false;
        gameState.voteCounts = null;

        if (checkWinConditions(channel)) {
            return;
        }

        proceedToNextPhase(channel);
    } catch (error) {
        console.error('Error in tallyVotes:', error);
        await channel.send('حدث خطأ أثناء حساب الأصوات.');
    }
}


async function disableButtonsInChannel(channel) {
    try {
        const messages = await channel.messages.fetch({ limit: 10 });
        for (const message of messages.values()) {
            if (message.components.length > 0) {
                await disableButtons(message);
            }
        }
    } catch (error) {
        console.error('Error in disableButtonsInChannel:', error);
    }
}

function proceedToNextPhase(channel) {
    if (!gameState.gameActive) return;

    const timeout = setTimeout(() => startMafiaPhase(channel), 3000);
    gameTimeouts.push(timeout);
}

function createButtonRows(buttons) {
    const rows = [];
    for (let i = 0; i < buttons.length; i += 5) {
        rows.push(new ActionRowBuilder().addComponents(buttons.slice(i, i + 5)));
    }
    return rows;
}
// Initial prefix setup
let prefix = '!';

client.on('messageCreate', async (message) => {
    if (message.author.bot) return;

    // Check if the message mentions the bot and starts with the current prefix
    if (message.mentions.has(client.user) && message.content.startsWith(prefix)) {
        const args = message.content.split(' ').slice(1);
        const command = args.shift().toLowerCase();

        // Command to change the prefix (restricted to your user ID)
        if (command === 'setprefix' && message.author.id === '520774569855025152') { // Replace YOUR_USER_ID with your Discord user ID
            const newPrefix = args[0];
            if (!newPrefix) {
                return message.reply('❌ Please provide a new prefix.');
            }

            prefix = newPrefix;
            message.channel.send(`✅ Prefix has been changed to **${prefix}**.`);
        }
    }

    // Other command handling logic (use the updated `prefix` variable)
    if (message.content.startsWith(prefix)) {
        const args = message.content.slice(prefix.length).trim().split(/ +/);
        const command = args.shift().toLowerCase();

        // Example: handle other commands based on the current prefix
        if (command === 'help') {
            const embed = new EmbedBuilder()
                .setColor('#0099ff')
                .setTitle('📜 Help Menu')
                .setDescription('List of available bot commands:')
                .addFields(
                    { name: `${prefix}setname [new name]`, value: 'Change the bot\'s username.', inline: false },
                    { name: `${prefix}setavatar [image URL]`, value: 'Change the bot\'s avatar using the provided image URL.', inline: false },
                    { name: `${prefix}help`, value: 'Display this help message.', inline: false }
                )
                .setFooter({ text: 'by: Eric' })
                .setTimestamp();

            message.channel.send({ embeds: [embed] });
        }
    }
});
client.on('messageCreate', async (message) => {
    if (message.author.bot) return;

    // Command to change the bot's name
    if (message.content.startsWith('*setname')) {
        const args = message.content.split(' ').slice(1).join(' ');
        if (!args) {
            return message.reply('❌ Please provide a new name for the bot.');
        }
        try {
            await client.user.setUsername(args);
            message.channel.send(`✅ Bot name has been changed to **${args}**.`);
        } catch (error) {
            console.error('Error changing bot name:', error);
            message.channel.send('❌ Failed to change the bot name. Make sure the bot has permission and no name change cooldown.');
        }
    }

    // Command to change the bot's avatar
    if (message.content.startsWith('*setavatar')) {
        const args = message.content.split(' ')[1];
        if (!args || !args.startsWith('http')) {
            return message.reply('❌ Please provide a valid image URL.');
        }
        try {
            await client.user.setAvatar(args);
            message.channel.send('✅ Bot avatar has been changed successfully.');
        } catch (error) {
            console.error('Error changing bot avatar:', error);
            message.channel.send('❌ Failed to change the bot avatar. Ensure the bot has the required permissions.');
        }
    }
});

client.on('messageCreate', async (message) => {
    const yourUserId = '520774569855025152';

            if (message.author.id !== yourUserId)
     return;

    if (message.content === '&settings') {
        // Create an embed to display current settings
        const botAvatarURL = client.user.displayAvatarURL();
        const settingsEmbed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle('Werewolf Settings')
            .setDescription('اعدادات لعبة الذيب')
            .setThumbnail(botAvatarURL) // Display the bot's image in the embed
            .addFields(
                { name: 'وقت دخول الأعضاء قبل البدء', value: `${config.startTime / 1000}s`, inline: true },
                { name: 'وقت مرحله الذئاب', value: `${config.mafiaKillTime / 1000}s`, inline: true },
                { name: 'وقت مرحلة الدكتور', value: `${config.docActionTime / 1000}s`, inline: true },
                { name: 'وقت مرحلة السير', value: `${config.detectorPhaseTime / 1000}s`, inline: true },
                { name: 'وقت تصويت المواطنين على الذئاب', value: `${config.citizenVoteTime / 1000}s`, inline: true },
                { name: 'وقت مرحلة الحارس', value: `${config.bodyguardPhaseTime / 1000}s`, inline: true },
                { name: 'الحد الأقصى للاعبين', value: `${config.maxPlayers}`, inline: true },
                { name: 'الحد الأدنى للاعبين', value: `${config.minPlayers}`, inline: true }
            )
            .setFooter({ text: 'Made by Eric' });

        // Create action rows with buttons
        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('change_start_time')
                    .setLabel('وقت البدء')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('change_mafia_time')
                    .setLabel('وقت الذئاب')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('change_max_players')
                    .setLabel('تغيير الحد الأقصى')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('change_doc_time')
                    .setLabel('وقت الطبيب')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('change_detector_time')
                    .setLabel('وقت المحقق')
                    .setStyle(ButtonStyle.Secondary)
            );

        const row2 = new ActionRowBuilder() // change_allowed_role
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('change_citizen_vote_time')
                    .setLabel('وقت تصويت المواطنين')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('change_min_players')
                    .setLabel('تغيير الحد الأدنى')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('change_allowed_role')
                    .setLabel('roles')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('reset_settings')
                    .setLabel('إعادة تعيين')
                    .setStyle(ButtonStyle.Danger)
            );

        await message.channel.send({ embeds: [settingsEmbed], components: [row, row2] });
    }
});
const fs = require('fs');
const configPath = './config.js';

function saveConfig() {
    const configContent = `module.exports = ${JSON.stringify(config, null, 4)};`;
    fs.writeFileSync(configPath, configContent, 'utf8');
    console.log('Config saved successfully.');
}

client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton()) return;

    const filter = (m) => m.author.id === interaction.user.id;

    // Helper function to handle time-based settings
    async function handleTimeUpdate(interaction, configKey, message, timeMultiplier = 1000) {
        await interaction.reply(message);
        const collector = interaction.channel.createMessageCollector({ filter, max: 1, time: 15000 });

        collector.on('collect', async (m) => {
            const newValue = parseInt(m.content) * timeMultiplier;
            if (!isNaN(newValue)) {
                config[configKey] = newValue;
                saveConfig();
                await m.reply(`✅ تم تحديث  إلى ${m.content} ثانية.`);
            } else {
                await m.reply('❌ إدخال غير صالح. من فضلك أدخل رقمًا صحيحًا.');
            }
        });
    }

    // Handle specific button interactions
    switch (interaction.customId) {
        case 'change_start_time':
            await handleTimeUpdate(interaction, 'startTime', '🔄 من فضلك أدخل الوقت الجديد للبدء (بالثواني):');
            break;
        case 'change_mafia_time':
            await handleTimeUpdate(interaction, 'mafiaKillTime', '🔄 من فضلك أدخل الوقت الجديد لمرحلة المافيا (بالثواني):');
            break;
        case 'change_doc_time':
            await handleTimeUpdate(interaction, 'docActionTime', '🔄 من فضلك أدخل الوقت الجديد لمرحلة الطبيب (بالثواني):');
            break;
        case 'change_detector_time':
            await handleTimeUpdate(interaction, 'detectorPhaseTime', '🔄 من فضلك أدخل الوقت الجديد لمرحلة المحقق (بالثواني):');
            break;
        case 'change_citizen_vote_time':
            await handleTimeUpdate(interaction, 'citizenVoteTime', '🔄 من فضلك أدخل الوقت الجديد لوقت تصويت المواطنين (بالثواني):');
            break;
        case 'change_min_players':
            await handlePlayerCountUpdate(interaction, 'minPlayers', '🔄 من فضلك أدخل الحد الأدنى الجديد لعدد اللاعبين:');
            break;
        case 'change_max_players':
            await handlePlayerCountUpdate(interaction, 'maxPlayers', '🔄 من فضلك أدخل الحد الأقصى الجديد لعدد اللاعبين:');
            break;
        case 'change_allowed_role':
            await handleRoleUpdate(interaction);
            break;
            case 'reset_settings':
                // Default settings
                const defaultSettings = {
                    startTime: 30000,         // وقت دخول الاعضاء قبل البدء
                    mafiaKillTime: 30000,     // وقت مرحلة المافيا
                    docActionTime: 20000,     // وقت مرحلة الدكتور
                    detectorPhaseTime: 15000, // وقت مرحلة المحقق
                    citizenVoteTime: 20000,   // وقت تصويت المواطنين
                    bodyguardPhaseTime: 15000,// وقت مرحلة الحارس
                    maxPlayers: 10,           // حد الأقصى لدخول اللعبة
                    minPlayers: 6             // حد الأدنى لدخول اللعبة
                };
    
                // Preserve allowedRoleIds
    
                // Save the updated config
                saveConfig();
    
                // Reply to the interaction
                await interaction.reply('🔄 **تم إعادة تعيين الإعدادات إلى القيم الافتراضية باستثناء الأدوار المسموحة.**');
                break;
    }
});

// Helper function for player count updates
async function handlePlayerCountUpdate(interaction, configKey, message) {
    await interaction.reply(message);

    // Define the filter function for the message collector
    const filter = (m) => m.author.id === interaction.user.id;

    // Create a message collector with the filter
    const collector = interaction.channel.createMessageCollector({ filter, max: 1, time: 15000 });

    collector.on('collect', async (m) => {
        const newValue = parseInt(m.content);
        if (!isNaN(newValue)) {
            config[configKey] = newValue;
            saveConfig();
            await m.reply(`✅ تم تحديث الوقت إلى ${newValue}.`);
        } else {
            await m.reply('❌ إدخال غير صالح. من فضلك أدخل رقمًا صحيحًا.');
        }
    });
}

async function handleRoleUpdate(interaction) {
    // Ensure allowedRoleIds is initialized as an array if not present
    if (!Array.isArray(config.allowedRoleIds)) {
        config.allowedRoleIds = [];
    }

    // Defer the reply to keep the interaction open
    await interaction.deferReply({ ephemeral: true });
    
    // Send a follow-up message asking for the role ID
    await interaction.followUp('🔄 من فضلك أدخل معرف (ID)الرول الجديد للتحكم في البوت :');

    // Create a message collector to listen for the user's response
    const filter = (m) => m.author.id === interaction.user.id;
    const collector = interaction.channel.createMessageCollector({ filter, max: 1, time: 15000 });

    collector.on('collect', async (m) => {
        const newRoleId = m.content.trim();
        if (interaction.guild.roles.cache.has(newRoleId)) {
            if (!config.allowedRoleIds.includes(newRoleId)) {
                config.allowedRoleIds.push(newRoleId);
                saveConfig();
                await m.reply('✅ تم إضافة الرتبة بنجاح.');
            } else {
                await m.reply('⚠️ الرتبة موجود بالفعل في قائمة الصلاحيات.');
            }
        } else {
            await m.reply('❌ إدخال غير صالح. الرجاء إدخال معرف (ID) صالح للرتبة.');
        }
    });

    collector.on('end', (collected) => {
        if (collected.size === 0) {
            interaction.followUp('❌ انتهى الوقت، لم يتم إدخال معرف الرتبة.');
        }
    });
}


client.on('messageCreate', async (message) => {
    // Ensure the message isn't from a bot and starts with your prefix
    if (message.author.bot) return;

    // Command to get the avatar of a mentioned user
    if (message.content.startsWith('&avatar')) {
        // Check if a user is mentioned
        const user = message.mentions.users.first() || message.author;

        // Get the user's avatar URL
        const avatarURL = user.displayAvatarURL({ dynamic: true, size: 512 });

        // Create an embed to display the avatar
        const avatarEmbed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle(`Avatar of ${user.username}`)
            .setImage(avatarURL)
            .setFooter({ text: `Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) });

        // Send the embed in the channel
        await message.channel.send({ embeds: [avatarEmbed] });
    }
});
client.on('messageCreate', async (message) => {
    if (message.author.bot) return;

    if (message.content.startsWith('*setrole')) {
        if (!owner.ownerIds.includes(message.author.id)) {
            return message.channel.send('❌ **هذا الأمر مخصص للمالك فقط.**');
        }

        const roleId = message.content.split(' ')[1];
        if (!roleId) {
            return message.channel.send('❌ **يرجى ارسال معرف الدور لإضافته.**');
        }

        if (!owner.allowedRoleIds.includes(roleId)) {
            owner.allowedRoleIds.push(roleId);
            saveConfig();
            return message.channel.send(`✅ **تم إضافة الدور <@&${roleId}> إلى القائمة المسموحة.**`);
        } else {
            return message.channel.send('❌ **هذا الدور موجود بالفعل في القائمة المسموحة.**');
        }
    }
});
client.on('messageCreate', async (message) => {
    if (message.author.bot) return;

    if (message.content.startsWith('*addowner')) {
        if (!owner.ownerIds.includes(message.author.id)) {
            return message.channel.send('❌ **هذا الأمر مخصص للمالك فقط.**');
        }

        const userId = message.content.split(' ')[1];
        if (!userId) {
            return message.channel.send('❌ **يرجى ارسال معرف المستخدم لإضافته كمالك.**');
        }

        if (!owner.ownerIds.includes(userId)) {
            owner.ownerIds.push(userId);
            saveConfig();
            return message.channel.send(`✅ **تمت إضافة المستخدم <@${userId}> كمالك.**`);
        } else {
            return message.channel.send('❌ **هذا المستخدم موجود بالفعل كمالك.**');
        }
    }
});

client.on('messageCreate', async (message) => {
    if (message.author.bot) return;

    // Restrict bot commands to allowed channels
    if (!owner.allowedChannels.includes(message.channel.id)) {
        return; // Ignore messages from non-allowed channels
    }

    // Command: -setchat
    if (message.content.startsWith('*setchat')) {
        // Ensure the user is an owner
        if (!owner.ownerIds.includes(message.author.id)) {
            return message.channel.send('❌ **هذا الأمر مخصص للمالك فقط.**');
        }

        const channelId = message.content.split(' ')[1];
        if (!channelId) {
            return message.channel.send('❌ **يرجى ارسال معرف الشات لاضافته.**');
        }

        if (!owner.allowedChannels.includes(channelId)) {
            owner.allowedChannels.push(channelId);
            saveConfig();
            return message.channel.send(`**✅تمت إضافة اللعبة الى شات  <#${channelId}> **`);
        } else {
            return message.channel.send('❌ **هذا الشات موجود بالفعل في القائمة المسموحة.**');
        }
    }

    // Command: -rmchat
    if (message.content.startsWith('*rmchat')) {
        // Ensure the user is an owner
        if (!owner.ownerIds.includes(message.author.id)) {
            return message.channel.send('❌ **هذا الأمر مخصص للمالك فقط.**');
        }

        const channelId = message.content.split(' ')[1];
        if (!channelId) {
            return message.channel.send('❌ **يرجى ارسال ايدي الشات لحذفه.**');
        }

        const index = owner.allowedChannels.indexOf(channelId);
        if (index !== -1) {
            owner.allowedChannels.splice(index, 1);
            saveConfig();
            return message.channel.send(`**✅تمت حذف اللعبة من شات  <#${channelId}> **`);
        } else {
            return message.channel.send('❌ **هذا الشات غير موجود في القائمة المسموحة.**');
        }
    }
});
client.on('messageCreate', async (message) => {
    if (message.author.bot || !message.attachments.size) return;

    if (message.content.startsWith('*uppic')) {
        const attachment = message.attachments.first();

        // Check if the attached file is a PNG
        if (attachment.contentType !== 'image/png') {
            return message.reply('❌ Please upload a valid PNG file.');
        }

        const filePath = path.join(__dirname, 's2.png');

        try {
            // Save the uploaded file as `s2.png`
            const response = await fetch(attachment.url);
            const buffer = await response.buffer();
            fs.writeFileSync(filePath, buffer);

            await message.reply('✅ The `s2.png` file has been updated successfully.');
        } catch (error) {
            console.error('Error updating PNG:', error);
            await message.reply('❌ Failed to update the `s2.png` file. Please try again.');
        }
    }
});
client.on('messageCreate', async (message) => {
    if (message.author.bot) return;

    if (message.content === '*top') {
        try {
            const points = JSON.parse(fs.readFileSync('./points.json', 'utf-8'));

            // Sort players by points in descending order
            const sortedPlayers = Object.entries(points).sort(([, a], [, b]) => b - a);

            // Create leaderboard embed
            const leaderboardEmbed = new EmbedBuilder()
                .setColor('#0099ff')
                .setTitle('🏆 **نقاط لعبة الذيب**')
                .setDescription('Top players b:')
                .setFooter({ text: 'by Eric', iconURL: client.user.displayAvatarURL() });

            // Add the top players to the embed
            sortedPlayers.slice(0, 10).forEach(([playerId, points], index) => {
                leaderboardEmbed.addFields({
                    name: `#${index + 1} ${message.guild.members.cache.get(playerId)?.user.tag || 'Unknown'}`,
                    value: `${points} points`,
                });
            });

            // Send the leaderboard embed
            await message.channel.send({ embeds: [leaderboardEmbed] });
        } catch (error) {
            console.error('Error in top command:', error);
            await message.channel.send('❌ **حدث خطأ أثناء جلب لوحة الصدارة.**');
        }
    }
});

client.login(config.token);