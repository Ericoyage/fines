module.exports = {
    "token": "MTMwMTg1NTExNjA5MzI5NjY0MA.GNsf1f.RZkGkUV_uZ7yp1ULS12U78lGbwjil4Nzb0z7Ps",
    "startTime": 35000,
    "mafiaKillTime": 30000,
    "docActionTime": 20000,
    "detectorPhaseTime": 15000,
    "citizenVoteTime": 20000,
    "bodyguardPhaseTime": 15000,
    "allowedRoleId": "ID",
    "maxPlayers": 25,
    "minPlayers": 6,
    "allowedRoleIds": [
        "1279144205314424913"
    ]
};